//create a function that adds two numbers and alerts the sum

function addTwoNumbers(num1, num2){
    const sum = num1 + num2
    alert( sum )
}

addTwoNumbers(2,3)

//create a function that multiplys three numbers and console logs the product

function multiplysThreeNumbers(zebra1,zebra2,zebra3){
    const product = zebra1 * zebra2 * zebra3
    console.log(product)
}

multiplysThreeNumbers(2,3,4)

//create a function that divides two numbers and returns the ???

function dividesTwoNumbers(n1,n2){
    return n1 / n2
} 

console.log(dividesTwoNumbers(12,6))