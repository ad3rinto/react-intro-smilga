//Create an a class and extend it - Can be anything you would like it to be! 

