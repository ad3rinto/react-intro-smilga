document.querySelector('#finalRose').addEventListener('click', /*INSERTCODE*/)

function hide(){
	document.querySelector(/*INSERTCODE*/).style.display = 'none'
	document.querySelector(/*INSERTCODE*/).style.display = 'none'
}
