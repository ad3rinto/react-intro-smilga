//Create a pizza object that has four properties and three methods

let pizzaTwo = {}

pizzaTwo.size = 'small'
pizzaTwo.toppings = ['spinach','onion','jalapenos', ,'garlic']
pizzaTwo.crust = 'thin'
pizzaTwo.sauce = 'normal'

pizzaTwo.estimatedDeliveryTime = function(){
    console.log('Calculating...')
}
pizzaTwo.burnMouth = function(){
    console.log('FFJkadjfl;kasjdfifj')
}
pizzaTwo.frisbee = function(){
    console.log('YEEEeeeetttt')
}



let pizza = {}

pizza.size = 'large'
pizza.toppings = ['spinach','onion','jalapenos', 'banana peppers','garlic']
pizza.crust = 'stuffed'
pizza.sauce = 'heavy'

pizza.estimatedDeliveryTime = function(){
    console.log('Calculating...')
}
pizza.burnMouth = function(){
    console.log('FFJkadjfl;kasjdfifj')
}
pizza.frisbee = function(){
    console.log('YEEEeeeetttt')
}