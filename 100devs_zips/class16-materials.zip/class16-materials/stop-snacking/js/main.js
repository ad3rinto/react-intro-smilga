//Create a function that grabs the number of snacks from the input and tells you to stop that many times
